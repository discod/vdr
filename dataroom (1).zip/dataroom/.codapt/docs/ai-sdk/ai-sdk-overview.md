We can use Vercel's AI SDK, `ai` version `^4.3.10`, along with its model integrations:

- `@ai-sdk/openai` version `^1.3.20`
- `@ai-sdk/anthropic` version `^1.2.10`
